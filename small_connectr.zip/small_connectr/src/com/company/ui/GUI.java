package com.company.ui;

import com.company.product.Game;
import com.company.product.Grid;
import com.company.product.Main;

import java.awt.*;

import java.net.URL;
import java.util.List;
import java.util.stream.IntStream;
import javax.swing.*;

public class GUI extends UI {
    public static final int FRAME_WIDTH = 800;
    public static final int FRAME_HEIGHT = 600;

    private JFrame mainFrame;
    private JPanel statusPanel;   //included inside JFrame
    private JPanel gridPanel;

    private String decision;
    /*
    In order to avoid blocking the program, two implementations are possible for the GUI : threads or keeping the game loop flow.
    We implemented here the GUI with keeping the game loop flow (different states for the game, and a decision input here which is always updated)
    A game loop refresh rate was implemented in Main in order to :
    - control the processor utilization (keeping it to a minimal rate)
    - allow future improvements such as game animations (e.g explosions when the player carries out a connect 4 win...etc)
     */

    public GUI(Grid grid, List<Integer> score) {
        //Main Frame
        this.mainFrame = new JFrame(Main.PROGRAM_NAME);
        this.mainFrame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        this.mainFrame.setLayout(new BoxLayout(this.mainFrame.getContentPane(), BoxLayout.Y_AXIS)); //Attention getContentPane() again
        this.mainFrame.setDefaultLookAndFeelDecorated(true);
        this.mainFrame.setVisible(true);
        this.mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Prepare status
        this.statusPanel = new JPanel();
        this.statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.Y_AXIS));

        //Prepare grid
        this.gridPanel = new JPanel();

        //Attach
        this.mainFrame.add(statusPanel);
        this.mainFrame.add(gridPanel);

        //Build components
        displayStatus("Welcome to " + Main.PROGRAM_NAME, score);
        displayGrid(grid);

        //Data
        this.decision = UI.NO_DECISION_YET;
    }

    @Override
    public void displayGrid(Grid grid) {
        char[][] dataGrid = grid.getGrid();
        int height = grid.getHeight();
        int width = grid.getWidth();

        //Clear
        this.gridPanel.removeAll();

        //Panel
        JPanel gridInside = new JPanel();
        gridInside.setLayout(new GridLayout(height,width));

        //Fill
        IntStream.range(0, height).forEach(i ->{    //Java8 Lambda, Functional loop, new feature v8
            IntStream.range(0, width).forEach(j ->{
                JButton square = new JButton();
                setGraphics(square, dataGrid[i][j]);    //set icon
                square.addActionListener(e -> actionPlay(i, j, grid));  //lambda function
                gridInside.add(square);
            });
        });
        this.gridPanel.add(gridInside);

        //Refresh
        this.gridPanel.revalidate();
        this.gridPanel.repaint();
    }

    @Override
    protected void displayStatus(String statusMsg, List<Integer> score) {
        //Clear
        this.statusPanel.removeAll();

        //Build component : score
        String scoreLine = "Score: ";
        for (int playerScore : score) {
            scoreLine +=  playerScore + "/" ;
        }
        JLabel scoreLabel = new JLabel(scoreLine, JLabel.CENTER);
        scoreLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        this.statusPanel.add(scoreLabel);

        //Build component : msg
        JLabel msgLabel = new JLabel(statusMsg, JLabel.CENTER);
        msgLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        this.statusPanel.add(msgLabel);

        //Build component : quit button
        JButton quitButton = new JButton("Quit");
        quitButton.addActionListener(e -> actionQuit());
        quitButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        this.statusPanel.add(quitButton);

        //Build component : resume button
        if(statusMsg.equals(UI.MSG_VICTORY) || statusMsg.equals(UI.MSG_DRAW)) {
            JButton resumeButton = new JButton("Resume");
            resumeButton.addActionListener(e -> actionResume());
            resumeButton.setAlignmentX(Component.LEFT_ALIGNMENT);
            this.statusPanel.add(resumeButton);
        }

        //Refresh
        this.statusPanel.revalidate();
        this.statusPanel.repaint();
    }

    private void setGraphics(JButton square, char tokenValue) {
        String imagePath = "/images/";
        switch(tokenValue) {
            case '.':
                imagePath += "empty.png";
                break;
            case 'x':
                imagePath += "red.png";
                break;
            case 'o':
                imagePath += "blue.png";
                break;
        }

        URL tokenImg = getClass().getResource(imagePath);
        square.setIcon(new ImageIcon(tokenImg));
    }

    private void actionPlay(int i, int j, Grid grid) {
        char[][] dataGrid = grid.getGrid();

        if(dataGrid[i][j] == '.') { //Otherwise token positioned on taken position
            this.decision = Integer.toString(j+1);
        }
    }

    private void actionQuit() {
        this.decision = Game.QUIT_CMD;
    }

    private void actionResume() {
        this.decision = Game.RESUME_CMD;
    }

    @Override
    public String requestDecision() {
        String requested = this.decision;
        this.decision = UI.NO_DECISION_YET; //reset to no decision

        return requested;
    }

}
