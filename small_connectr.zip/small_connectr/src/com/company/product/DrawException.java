package com.company.product;

class DrawException extends Exception{

}