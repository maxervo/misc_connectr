package com.company.product;

class VictoryException extends Exception {

}
